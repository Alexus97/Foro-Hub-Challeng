package com.lexcorp.Foro_Hub_Challeng;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ForoHubChallengApplication {

	public static void main(String[] args) {
		SpringApplication.run(ForoHubChallengApplication.class, args);
	}

}
