package com.lexcorp.Foro_Hub_Challeng;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForoHubChallengApplicationTests {

	@Test
	void contextLoads() {
	}

}
